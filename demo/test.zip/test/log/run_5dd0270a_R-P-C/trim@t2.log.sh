#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd0270a_R-P-C
NC=2
NG=2
################################################################
sample='''t2'''

adapter3='''AAAAAAAAAA'''
adapter5='''CCCCCCCCCC'''
evalue='''1E-20'''
rawdata='''rawdata/Sample_XXXXX'''
read_minlen='''35'''
seconds=''''''
Trimmomatic='''java -Djava.io.tmpdir=./tmp -jar /opt/Trimmomatic-0.36/trimmomatic-0.36.jar'''
################################################################
echo "$sample trimming..."
echo $sample, $rawdata, $adapter3, $adapter5, $read_minlen

if [ -z $seconds ]; then
	echo "seconds of $sample wasn't set, using a random one"
	seconds=$(seq 40 60 | shuf -n 1)
fi

sleep $seconds
echo "done"

exit
################################################################
StartAt: 2019-11-16T16:43:49Z

t2 trimming...
t2, rawdata/Sample_XXXXX, AAAAAAAAAA, CCCCCCCCCC, 35
seconds of t2 wasn't set, using a random one
done

EndAt: 2019-11-16T16:44:47Z
