#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd026e8_HELLO
NC=8
NG=8
################################################################
################################################################
echo "hello, world"
$MAIN read log/$RUNNER/project.ini
$MAIN read log/$RUNNER/project.ini sample::rawdata
$MAIN read log/$RUNNER/project.ini sample::rawdata t1
$MAIN s2j log/$RUNNER/project.ini group

exit
################################################################
StartAt: 2019-11-16T16:42:16Z

hello, world
DEFAULT
group
@trim
sample::adapter3
sample::evalue@trim
sample::rawdata
sample::seconds
somatic::vs
n1
n2
t1
t2
rawdata/Sample_123_A
rawdata/Sample_456_A
{
  "group": {
    "n": [
      "n1  n2",
      "n3",
      ""
    ],
    "t": [
      "t1",
      "t2"
    ]
  }
}

EndAt: 2019-11-16T16:42:16Z
