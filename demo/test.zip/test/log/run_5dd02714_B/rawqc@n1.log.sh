#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd02714_B
NC=2
NG=2
################################################################
sample='''n1'''

evalue='''1E-5'''
Pipeline='''P1'''
rawdata='''rawdata/Sample_123_B'''
################################################################
echo "MAIN: $MAIN"
echo "RUNNER: $RUNNER"
echo "Pipeline: $Pipeline"
echo "Project config: log/$RUNNER/project.ini"
ls -al log/$RUNNER/project.ini
echo
echo $sample, $rawdata, $NC
## do FastQC
echo "FastQC"
sleep $(seq 40 60 | shuf -n 1)

echo "Done"

exit
################################################################
StartAt: 2019-11-16T16:43:00Z

MAIN: /mnt/HostPath/demo/test/ABC_wf/ABC
RUNNER: run_5dd02714_B
Pipeline: P1
Project config: log/run_5dd02714_B/project.ini
-rw-r--r-- 1 ubuntu ubuntu 513 Nov 16 16:43 log/run_5dd02714_B/project.ini

n1, rawdata/Sample_123_B, 2
FastQC
Done

EndAt: 2019-11-16T16:43:40Z
