#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd02714_B
NC=8
NG=8
################################################################
sample='''t2 n2 n1 t1'''

G1=''''''
################################################################
echo "G1 = $G1"
echo "Samples:"
for i in $sample; do
	echo $i
done

exit
################################################################
StartAt: 2019-11-16T16:44:53Z

G1 = 
Samples:
t2
n2
n1
t1

EndAt: 2019-11-16T16:44:53Z
