#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd02714_B
NC=2
NG=2
################################################################
sample='''t1'''

adapter3='''AAAAAAAAAA'''
adapter5='''CCCCCCCCCC'''
evalue='''1E-10'''
rawdata='''rawdata/Sample_123_A
rawdata/Sample_456_A'''
read_minlen='''35'''
seconds='''70'''
Trimmomatic='''java -Djava.io.tmpdir=./tmp -jar /opt/Trimmomatic-0.36/trimmomatic-0.36.jar'''
################################################################
echo "$sample trimming..."
echo $sample, $rawdata, $adapter3, $adapter5, $read_minlen

if [ -z $seconds ]; then
	echo "seconds of $sample wasn't set, using a random one"
	seconds=$(seq 40 60 | shuf -n 1)
fi

sleep $seconds
echo "done"

exit
################################################################
StartAt: 2019-11-16T16:43:43Z

t1 trimming...
t1, rawdata/Sample_123_A rawdata/Sample_456_A, AAAAAAAAAA, CCCCCCCCCC, 35
done

EndAt: 2019-11-16T16:44:53Z
