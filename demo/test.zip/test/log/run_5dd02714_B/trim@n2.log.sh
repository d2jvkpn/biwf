#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd02714_B
NC=2
NG=2
################################################################
sample='''n2'''

adapter3='''AAAAAAAAAA'''
adapter5='''CCCCCCCCCC'''
evalue='''1E-10'''
rawdata='''rawdata/Sample_YYYYY'''
read_minlen='''35'''
seconds=''''''
Trimmomatic='''java -Djava.io.tmpdir=./tmp -jar /opt/Trimmomatic-0.36/trimmomatic-0.36.jar'''
################################################################
echo "$sample trimming..."
echo $sample, $rawdata, $adapter3, $adapter5, $read_minlen

if [ -z $seconds ]; then
	echo "seconds of $sample wasn't set, using a random one"
	seconds=$(seq 40 60 | shuf -n 1)
fi

sleep $seconds
echo "done"

exit
################################################################
StartAt: 2019-11-16T16:43:42Z

n2 trimming...
n2, rawdata/Sample_YYYYY, AAAAAAAAAA, CCCCCCCCCC, 35
seconds of n2 wasn't set, using a random one
done

EndAt: 2019-11-16T16:44:36Z
