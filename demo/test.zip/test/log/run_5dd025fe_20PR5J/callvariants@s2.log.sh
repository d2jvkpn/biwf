#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd025fe_20PR5J
NC=4
NG=4
################################################################
somatic='''s2'''

evalue='''1E-15'''
vs='''t2 n2'''
################################################################
#OIFS=$IFS; IFS=" "; set -- $vs; tumor=$1; normal=$2; IFS=$OIFS 
   p=($vs)
   if [ ${#p[*]} -eq 2 ]; then
     echo "detected tumor and normal!"
   else
     echo "invald tumor and normal: $vs"
     exit 1
   fi
echo "tumor sample: ${p[0]}"
echo "normal sample: ${p[1]}"

ls log/$RUNNER/callvariants@$somatic.json
echo "Start calling variants"
seconds=$(seq 30 60 | shuf -n 1)
sleep $seconds

echo "Done!"

exit
################################################################
StartAt: 2019-11-16T16:41:49Z

detected tumor and normal!
tumor sample: t2
normal sample: n2
log/run_5dd025fe_20PR5J/callvariants@s2.json
Start calling variants
Done!

EndAt: 2019-11-16T16:42:40Z
