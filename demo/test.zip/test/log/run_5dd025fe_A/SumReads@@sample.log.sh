#! /bin/bash
set -eu -o pipefail
MAIN='''/mnt/HostPath/demo/test/ABC_wf/ABC'''
MAINDIR='''/mnt/HostPath/demo/test/ABC_wf'''
WORKPATH='''/mnt/HostPath/demo/test'''
RUNNER=run_5dd025fe_A
NC=8
NG=8
################################################################
sample='''t1 t2 n1 n2'''

G1=''''''
################################################################
echo "G1 = $G1"
echo "Samples:"
for i in $sample; do
	echo $i
done

exit
################################################################
StartAt: 2019-11-16T16:40:25Z

G1 = 
Samples:
t1
t2
n1
n2

EndAt: 2019-11-16T16:40:25Z
