#! /bin/bash
# project: https://github.com/d2jvkpn/biwf
set -eu -o pipefail

MAIN="$(dirname $0)/ABC" # customize it
IMG="centos"             # customize it
MAIN=$(readlink -f $MAIN)

args=($(for v in "$@"; do
  if [[ "$v" == *" "* ]]; then echo "\"$v\""; else echo $v; fi
done))

test $# -eq 0 && { echo "no input args"; exit 1; }

proj=$($MAIN read project.ini "" Project)
test -z "$proj" && { echo "Please set \"Project\" in project.ini"; exit 1; }

container=${proj}_$(printf "%x" $(date +"%s"))
MAINDIR=$(dirname $MAIN); uid=$(id -u)

echo "Creating \"$container\"..."
# echo ${args[*]}
if [[ "$(id -n -u)" == root ]]; then
  docker run --rm --name=$container -v=$PWD:/mnt/HostPath -v=$MAINDIR:$MAINDIR \
  -w /mnt/HostPath $IMG sh -l -c "$MAIN run ${args[*]}"
else
  docker run --rm --name=$container -v=$PWD:/mnt/HostPath -v=$MAINDIR:$MAINDIR \
  $IMG sh -c "useradd -u $uid u$uid && su u$uid -l -c \
  'cd /mnt/HostPath && $MAIN run ${args[*]}'"
fi
